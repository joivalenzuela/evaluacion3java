package com.mycompany.sistemadeventas.modelo;

import com.mycompany.sistemadeventas.modelo.interfaces.ProductoDAO;
import java.util.ArrayList;
import java.util.HashMap;


public class AdministradorProducto implements ProductoDAO{
    ArrayList<Producto> listaProductos;

    public AdministradorProducto() {
        listaProductos = new ArrayList<>();
    }

    
    
    @Override
    public HashMap<String,Object> registrarProducto(Producto p) {
        HashMap<String,Object> resultadoRegistrar = new HashMap<>();
        
        for(Producto pr : listaProductos){
            if(pr.getId() == null ? p.getId() == null : pr.getId().equals(p.getId())){
                setResult(resultadoRegistrar, false, "Ya existe un producto con la id ingresada");
                return resultadoRegistrar;
            }
        }
        if(p.getId() == null || p.getId().isEmpty() || p.getMarca() == null || p.getMarca().isEmpty() || p.getNombre() == null || p.getNombre().isEmpty()){
            setResult(resultadoRegistrar, false, "Todos los campos son obligatorios");
        }else if(p.getPrecio()<=0){
            setResult(resultadoRegistrar, false, "Precio no valido");
        }else if(p instanceof Mouse m){   
            if(m.getCantidadBotones()<2){
                setResult(resultadoRegistrar, false, "Los mouse deben tener por lo menos 2 botones");
            }else{
                setResult(resultadoRegistrar, true, "Producto Registrado Correctamente");
                listaProductos.add(m);
            }
        }else if(p instanceof Audifonos a){
            setResult(resultadoRegistrar, true, "Producto Registrado Correctamente");
            listaProductos.add(a);
        }
        return resultadoRegistrar;
    }

    
    
    @Override
    public ArrayList<Producto> obtenerProductos() {
        return listaProductos;
    }

    
    
    public ArrayList<Producto> obtenerProductos(String modo){
        if("m".equals(modo)){
            ArrayList<Producto> listaMouse = new ArrayList<>();
            for(Producto p: listaProductos){
                if(p instanceof Mouse m){
                    listaMouse.add(m);
                }
            }
            return listaMouse;
        }
        else if("a".equals(modo)){
            ArrayList<Producto> listaAudifonos = new ArrayList<>();
            for(Producto p: listaProductos){
                if(p instanceof Audifonos a){
                    listaAudifonos.add(a);
                }
            }
            return listaAudifonos;
        }
        return listaProductos;
    }
    
    
    
    
    
    @Override
    public Producto buscarProducto(String id) {
        for(Producto p : listaProductos){
            if(p.getId().equalsIgnoreCase(id)){
               return p;
            }
        }
        return null;
    }
    
    private void setResult(HashMap<String, Object> resultMap, boolean success, String message) {
        resultMap.put("resultado", success);
        resultMap.put("texto", message);
    }
}
