package com.mycompany.sistemadeventas.modelo.interfaces;

import com.mycompany.sistemadeventas.modelo.Cliente;
import com.mycompany.sistemadeventas.modelo.Producto;
import java.util.ArrayList;
import java.util.HashMap;


public interface VentaDAO {
    
    HashMap<String,Object> realizarVenta(Cliente c,ArrayList<Producto> p,double pago);
    
}

