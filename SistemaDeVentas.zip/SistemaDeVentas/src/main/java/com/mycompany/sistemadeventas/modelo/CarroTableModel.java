package com.mycompany.sistemadeventas.modelo;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class CarroTableModel extends AbstractTableModel {

    private List<Producto> liProductos;
    private String[] columnas={"id","Nombre","Marca","Precio"};
    
    public CarroTableModel(List<Producto> liProductos){
        this.liProductos=liProductos;
    }
    
    @Override
    public int getRowCount() {
        return liProductos.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Producto producto= liProductos.get(rowIndex);

        switch(columnIndex){
            case 0: return producto.getId();
            case 1: return producto.getNombre();
            case 2: return producto.getMarca();
            case 3: return producto.getPrecio();
            default: return null;
        }
    }
    
    
    @Override
    public String getColumnName(int columna){
        return columnas[columna];
    }
    
}
