package com.mycompany.sistemadeventas;

import com.mycompany.sistemadeventas.controlador.ControladorMain;
import com.mycompany.sistemadeventas.vista.MainFrame;
import javax.swing.JFrame;

public class SistemaDeVentas {

    public static void main(String[] args) {
        MainFrame mainFrame= new MainFrame();
        mainFrame.setVisible(true);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setTitle("PeripheriShop");
        ControladorMain mainFrameController= new ControladorMain(mainFrame);   
    }
    
}
