package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.CarroTableModel;
import com.mycompany.sistemadeventas.modelo.Cliente;
import com.mycompany.sistemadeventas.modelo.Producto;
import com.mycompany.sistemadeventas.modelo.interfaces.ClienteDAO;
import com.mycompany.sistemadeventas.modelo.interfaces.ProductoDAO;
import com.mycompany.sistemadeventas.modelo.interfaces.ReporteDAO;
import com.mycompany.sistemadeventas.modelo.interfaces.VentaDAO;
import com.mycompany.sistemadeventas.vista.FrameVenta;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.HashMap;


public class ControladorVenta {
    private final FrameVenta vistaVenta;
    private final VentaDAO ventaDao;
    private final ClienteDAO clienteDao;
    private final ReporteDAO reporteDao;
    private final ProductoDAO productoDao;
    
    public ControladorVenta(FrameVenta vistaVenta,VentaDAO ventaDao, ClienteDAO clienteDao, ProductoDAO productoDao,ReporteDAO reporteDao) {
        this.vistaVenta = vistaVenta;
        this.clienteDao = clienteDao;
        this.productoDao = productoDao;
        this.ventaDao = ventaDao;
        this.reporteDao = reporteDao;
        vistaVenta.getLblTotalPagar().setText("$ 0");
        
        agregarListeners();
    }

    private void agregarListeners() {
        
        //funcionalidad tecla enter en txt id Producto
        vistaVenta.getTxtIdVenta().addActionListener((ActionEvent e) -> {
            ArrayList<Producto> productos = productoDao.obtenerProductos();
            for(Producto p : productos){
                if(p.getId().equals(vistaVenta.getTxtIdVenta().getText())){
                    vistaVenta.getLblProductoEncontrado().setText(p.getNombre());
                    return;
                }
            }
            vistaVenta.getLblProductoEncontrado().setText("Producto no encontrado");
        });
        
       //funcionalidad tecla enter en txt rut
        vistaVenta.getTxtRut().addActionListener((ActionEvent e) -> {
            ArrayList<Cliente> clientes = clienteDao.obtenerClientes();
            for(Cliente c : clientes){
                if(c.getRun().equals(vistaVenta.getTxtRut().getText())){
                    vistaVenta.getLblUsuarioEncontrado().setText(c.getNombreCompleto());
                    return;
                }
            }
            vistaVenta.getLblUsuarioEncontrado().setText("Cliente no encontrado");
        });
       
        //funcionalidad boton agregar
        vistaVenta.getBtnAgregarCarro().addActionListener((ActionEvent e) -> {
            if(vistaVenta.getTxtIdVenta() == null){
                vistaVenta.getLblProductoEncontrado().setText("Ingrese la id del producto");
                return;
            }     
            for(Producto p : productoDao.obtenerProductos()){
                if(p.getId().equalsIgnoreCase(vistaVenta.getTxtIdVenta().getText())){
                    if(ventaDao.agregarCarro(p)){
                        CarroTableModel modeloTablaVenta = new CarroTableModel(ventaDao.obtenerCarro());
                        vistaVenta.actualizarTablaCarro(modeloTablaVenta);
                        vistaVenta.getLblProductoEncontrado().setText("Producto Agregado al Carro");
                        vistaVenta.getTxtIdVenta().setText("");
                        vistaVenta.getLblTotalPagar().setText("$"+String.valueOf(ventaDao.costoCarro()));
                        return;
                    }else{
                        vistaVenta.getLblProductoEncontrado().setText("Producto ya agregado");
                        return;
                    }
                }    
            }
            vistaVenta.getLblProductoEncontrado().setText("No se encontro el producto");
        });
        
        //funcionalidad boton eliminar
        vistaVenta.getBotonEliminardelCarro().addActionListener((ActionEvent e) -> {
            String objetivoEliminar = vistaVenta.getTxtIdVenta().getText();
            
            if(objetivoEliminar == null){
                vistaVenta.getLblProductoEncontrado().setText("Ingrese una Id");
            }else{
                if(ventaDao.eliminarDelCarro(objetivoEliminar)){
                    vistaVenta.getLblProductoEncontrado().setText("Eliminado del Carro");    
                    CarroTableModel modeloTablaVenta = new CarroTableModel(ventaDao.obtenerCarro());
                    vistaVenta.actualizarTablaCarro(modeloTablaVenta);
                    vistaVenta.getLblTotalPagar().setText("$"+String.valueOf(ventaDao.costoCarro()));
                }else{
                    vistaVenta.getLblProductoEncontrado().setText("No esta en el carro");
                }
            }
        });
        
        
        //funcionalidad boton cancelar
        vistaVenta.getBtnCancelarOperacion().addActionListener((ActionEvent e) -> {
            ventaDao.limpiarCarro();
        });
        
        
        //funcionalidad boton pagar
        vistaVenta.getBtnPagarProducto().addActionListener((ActionEvent e) -> {
            ArrayList<Cliente> clientes = clienteDao.obtenerClientes();
            
            for(Cliente c : clientes){
                if(c.getRun().equals(vistaVenta.getTxtRut().getText())){    
                    HashMap<String,Object> respuesta = ventaDao.realizarVenta(c, Double.parseDouble(vistaVenta.getTxtPagar().getText()));     
                    if((boolean)respuesta.get("resultado")){
                        // Crear Reporte
                        String[] nProductos =  new String[ventaDao.obtenerCarro().size()];
                        String[] idProductos =  new String[ventaDao.obtenerCarro().size()];
                        int i = 0;
                        for(Producto p : ventaDao.obtenerCarro()){
                            nProductos[i] = p.getNombre();
                            idProductos[i] = p.getId();
                            i++;
                        } 
                        double precioTotal = 0;
                        for(Producto producto : ventaDao.obtenerCarro()){
                            precioTotal += producto.getPrecio();
                        }
                        reporteDao.crearReporte(idProductos,nProductos,c.getNombreCompleto(),c.getCorreoElectronico(),precioTotal);
                        
                        //Respuesta en pantalla a Usuario
                        vistaVenta.getLblInfoVenta().setText((String)respuesta.get("texto"));
                        vistaVenta.getLblInfoVuelto().setText("Vuelto: $"+String.valueOf((double)respuesta.get("vuelto")));
                        
                        //Resetear Carro
                        ventaDao.limpiarCarro();
                        CarroTableModel modeloTablaVenta = new CarroTableModel(ventaDao.obtenerCarro());
                        vistaVenta.actualizarTablaCarro(modeloTablaVenta);
                        return;
                    }else{
                        vistaVenta.getLblInfoVenta().setText((String)respuesta.get("texto"));
                        return;
                    }
                    
                }
            }
            vistaVenta.getLblUsuarioEncontrado().setText("Cliente no encontrado");
        });
    }
}
