package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.AdministradorVenta;
import com.mycompany.sistemadeventas.modelo.interfaces.VentaDAO;
import com.mycompany.sistemadeventas.vista.FrameVenta;


public class ControladorVenta {
    private FrameVenta vistaVenta;
    private VentaDAO ventaDao;

    public ControladorVenta(FrameVenta vistaVenta) {
        this.vistaVenta = vistaVenta;
        ventaDao = new AdministradorVenta();
        agregarListeners();
    }

    private void agregarListeners() {
        
    }
}
