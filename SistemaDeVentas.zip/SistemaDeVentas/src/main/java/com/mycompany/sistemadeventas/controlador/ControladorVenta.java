package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.AdministradorVenta;
import com.mycompany.sistemadeventas.modelo.CarroTableModel;
import com.mycompany.sistemadeventas.modelo.Cliente;
import com.mycompany.sistemadeventas.modelo.Producto;
import com.mycompany.sistemadeventas.modelo.Reporte;
import com.mycompany.sistemadeventas.modelo.interfaces.ClienteDAO;
import com.mycompany.sistemadeventas.modelo.interfaces.ProductoDAO;
import com.mycompany.sistemadeventas.modelo.interfaces.ReporteDAO;
import com.mycompany.sistemadeventas.modelo.interfaces.VentaDAO;
import com.mycompany.sistemadeventas.vista.FrameVenta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;


public class ControladorVenta {
    private FrameVenta vistaVenta;
    private VentaDAO ventaDao;
    private ClienteDAO clienteDao;
    private ReporteDAO reporteDao;
    private ProductoDAO productoDao;
    
    public ControladorVenta(FrameVenta vistaVenta,VentaDAO ventaDao, ClienteDAO clienteDao, ProductoDAO productoDao,ReporteDAO reporteDao) {
        this.vistaVenta = vistaVenta;
        this.clienteDao = clienteDao;
        this.productoDao = productoDao;
        this.ventaDao = ventaDao;
        this.reporteDao = reporteDao;
        vistaVenta.getLblTotalPagar().setText("$ 0");
        
        agregarListeners();
    }

    private void agregarListeners() {
        vistaVenta.getTxtIdVenta().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Producto> productos = productoDao.obtenerProductos();
                for(Producto p : productos){
                    if(p.getId().equals(vistaVenta.getTxtIdVenta().getText())){
                        vistaVenta.getLblProductoEncontrado().setText(p.getNombre());
                        return;
                    }
                }
                 vistaVenta.getLblProductoEncontrado().setText("Producto no encontrado");
            }
        });
        
       
        
        vistaVenta.getTxtRut().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Cliente> clientes = clienteDao.obtenerClientes();
                for(Cliente c : clientes){
                    if(c.getRun().equals(vistaVenta.getTxtRut().getText())){
                        vistaVenta.getLblUsuarioEncontrado().setText(c.getNombreCompleto());
                        return;
                    }
                }
                 vistaVenta.getLblUsuarioEncontrado().setText("Cliente no encontrado");
            }
        });
       
        vistaVenta.getBtnAgregarCarro().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(vistaVenta.getTxtIdVenta() == null){
                    vistaVenta.getLblProductoEncontrado().setText("Ingrese la id del producto");
                    return;
                }
               
                
                for(Producto p : productoDao.obtenerProductos()){
                    if(p.getId().equalsIgnoreCase(vistaVenta.getTxtIdVenta().getText())){
                        if(ventaDao.agregarCarro(p)){
                            CarroTableModel modeloTablaVenta = new CarroTableModel(ventaDao.obtenerCarro());
                            vistaVenta.actualizarTablaCarro(modeloTablaVenta);
                            vistaVenta.getLblProductoEncontrado().setText("Producto Agregado al Carro");
                            vistaVenta.getLblTotalPagar().setText("$"+String.valueOf(ventaDao.costoCarro()));
                            return;
                        }else{
                            vistaVenta.getLblProductoEncontrado().setText("Producto ya agregado");
                            return;
                        }
                    
                    }
                }  
                vistaVenta.getLblProductoEncontrado().setText("No se encontro el producto");    
                
            }
        });
        vistaVenta.getBotonEliminardelCarro().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String objetivoEliminar = vistaVenta.getTxtIdVenta().getText();
                if(objetivoEliminar == null){
                    vistaVenta.getLblProductoEncontrado().setText("Ingrese una Id");
                    
                }else{
                    if(ventaDao.eliminarDelCarro(objetivoEliminar)){
                        vistaVenta.getLblProductoEncontrado().setText("Eliminado del Carro");
                        CarroTableModel modeloTablaVenta = new CarroTableModel(ventaDao.obtenerCarro());
                        vistaVenta.actualizarTablaCarro(modeloTablaVenta);
                        vistaVenta.getLblTotalPagar().setText("$"+String.valueOf(ventaDao.costoCarro()));
                    }else{
                        vistaVenta.getLblProductoEncontrado().setText("No esta en el carro");
                    }
                    
                }  
            }
        });
        
        vistaVenta.getBtnCancelarOperacion().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ventaDao.limpiarCarro();
            }
        });
        
        vistaVenta.getBtnPagarProducto().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Cliente> clientes = clienteDao.obtenerClientes();
                for(Cliente c : clientes){
                    if(c.getRun().equals(vistaVenta.getTxtRut().getText())){
                        
                        HashMap<String,Object> respuesta = ventaDao.realizarVenta(c, Double.parseDouble(vistaVenta.getTxtPagar().getText()));
                        if((boolean)respuesta.get("resultado")){
                            ArrayList<String> nProductos = new ArrayList<>();
                            ArrayList<String> idProductos = new ArrayList<>();
                            for(Producto p : ventaDao.obtenerCarro()){
                                nProductos.add(p.getNombre());
                                idProductos.add(p.getId());
                            }
                            double precioTotal = 0;
                            for(Producto producto : ventaDao.obtenerCarro()){
                                precioTotal += producto.getPrecio();
                            }
                            reporteDao.crearReporte(idProductos,nProductos,c.getNombreCompleto(),c.getCorreoElectronico(),precioTotal);
                            
                            vistaVenta.getLblInfoVenta().setText((String)respuesta.get("texto"));
                            vistaVenta.getLblInfoVuelto().setText("Vuelto: $"+String.valueOf((double)respuesta.get("vuelto")));
                            ventaDao.limpiarCarro();
                            CarroTableModel modeloTablaVenta = new CarroTableModel(ventaDao.obtenerCarro());
                            vistaVenta.actualizarTablaCarro(modeloTablaVenta);
                            return;
                        }else{
                            vistaVenta.getLblInfoVenta().setText((String)respuesta.get("texto"));
                            return;
                        }
                        
                    }
                }
                vistaVenta.getLblUsuarioEncontrado().setText("Cliente no encontrado");
            
               
            }
        });
    }
}
