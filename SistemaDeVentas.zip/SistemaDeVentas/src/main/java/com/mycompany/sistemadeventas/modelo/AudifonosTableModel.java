package com.mycompany.sistemadeventas.modelo;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class AudifonosTableModel extends AbstractTableModel {

    private List<Producto> liAudifonos;
    private String[] columnas={"id","Nombre","Marca","Precio","Es inalambrico?","Microfono Incluido?"};
    
    public AudifonosTableModel(List<Producto> liAudifonos){
        this.liAudifonos=liAudifonos;
    }
    
    @Override
    public int getRowCount() {
        return liAudifonos.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Audifonos audifono= (Audifonos)liAudifonos.get(rowIndex);
        switch(columnIndex){
            case 0 : return audifono.getId();
            case 1: return audifono.getNombre();
            case 2: return audifono.getMarca();
            case 3: return audifono.getPrecio();
            case 4: 
                if(audifono.isEsInalambrico()){
                    return "Si";
                }else{
                    return "No";
                }
            case 5: 
                if(audifono.isMicrofonoIncluido()){
                    return "Si";
                }else{
                    return "No";
                }
            default: return null;
        }
    }
    
    
    @Override
    public String getColumnName(int columna){
        return columnas[columna];
    }
    
}
