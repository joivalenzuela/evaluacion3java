/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.vista.FrameCliente;
import com.mycompany.sistemadeventas.vista.MainFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;

/**
 *
 * @author Alvaro
 */
public class ControladorMain {
    private MainFrame vistaPrincipal;
    private FrameCliente vistaCliente;

    public ControladorMain(MainFrame vistaPrincipal) {
        this.vistaPrincipal = vistaPrincipal;
        this.vistaCliente = new FrameCliente();
        agregarListeners();
        
        
    }
    
    private void agregarListeners(){
       
        vistaPrincipal.getBtnCliente().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
            
                vistaCliente.setVisible(true);
                vistaCliente.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                ControladorCliente clienteControlador = new ControladorCliente(vistaCliente);
            }
        });
    }
}
                   
 
        