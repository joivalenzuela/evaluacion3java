package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.AdministradorCliente;
import com.mycompany.sistemadeventas.modelo.AdministradorProducto;
import com.mycompany.sistemadeventas.modelo.AdministradorReporte;
import com.mycompany.sistemadeventas.modelo.AdministradorVenta;
import com.mycompany.sistemadeventas.modelo.interfaces.ClienteDAO;
import com.mycompany.sistemadeventas.modelo.interfaces.ProductoDAO;
import com.mycompany.sistemadeventas.modelo.interfaces.ReporteDAO;
import com.mycompany.sistemadeventas.modelo.interfaces.VentaDAO;
import com.mycompany.sistemadeventas.vista.FrameCliente;
import com.mycompany.sistemadeventas.vista.FrameProducto;
import com.mycompany.sistemadeventas.vista.FrameReporte;
import com.mycompany.sistemadeventas.vista.FrameVenta;
import com.mycompany.sistemadeventas.vista.MainFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;

public class ControladorMain {
    private final MainFrame vistaPrincipal;
    private final FrameCliente vistaCliente;
    private final FrameProducto vistaProducto;
    private final FrameVenta vistaVenta;
    private final FrameReporte vistaReporte;
    ClienteDAO clienteDao;
    ProductoDAO productoDao;
    VentaDAO ventaDao;
    ReporteDAO reporteDao;
    
    public ControladorMain(MainFrame vistaPrincipal) {
        this.vistaPrincipal = vistaPrincipal;
        this.vistaCliente = new FrameCliente();
        this.vistaProducto = new FrameProducto();
        this.vistaVenta = new FrameVenta();
        this.vistaReporte = new FrameReporte();
        clienteDao= new AdministradorCliente();
        productoDao = new AdministradorProducto();
        ventaDao = new AdministradorVenta();
        reporteDao = new AdministradorReporte();
        agregarListeners();
    }
    
    private void agregarListeners(){
       
        vistaPrincipal.getBtnCliente().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
                ControladorCliente clienteControlador = new ControladorCliente(vistaCliente,clienteDao);
                vistaCliente.setVisible(true);
                vistaCliente.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            }
        });
        
        vistaPrincipal.getBtnProducto().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
                ControladorProducto productoControlador = new ControladorProducto(vistaProducto,productoDao);
                vistaProducto.setVisible(true);
                vistaProducto.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            }
        });
        
        vistaPrincipal.getBtnVenta().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
                ControladorVenta ventaControlador = new ControladorVenta(vistaVenta,ventaDao,clienteDao,productoDao,reporteDao);
                vistaVenta.setVisible(true);
                vistaVenta.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            }
        });
        
        vistaPrincipal.getBtnReporte().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorReporte ReporteControlador = new ControladorReporte(vistaReporte,reporteDao);
                vistaReporte.setVisible(true);
                vistaReporte.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            }
        });
        
        
        
        
        
        
        
        
        
        
        
    }
}
                   
 
        