package com.mycompany.sistemadeventas.modelo;

import com.mycompany.sistemadeventas.modelo.interfaces.ReporteDAO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class AdministradorReporte implements ReporteDAO{

    private final ArrayList<Reporte> listaReportes;
  
    public AdministradorReporte() {
        listaReportes = new ArrayList<>();
    }
    
    
    @Override
    public void reportarVenta(Cliente c,ArrayList<Producto> carro){
        
        Iterator<Reporte> rIterator = listarReportes().iterator();
        Iterator<Producto> pIterator = carro.iterator();


        Map<String, Reporte> reportMap = new HashMap<>();  

        // mapear cada reporte, si es que hay, con la id de su producto
        while (rIterator.hasNext()) {
            Reporte rProducto = rIterator.next();  
            reportMap.put(rProducto.getCodigoProducto(), rProducto); 
        }

        //se itera todo el carro
        while (pIterator.hasNext()) {
            //se guarda el producto de la iteracion actual para usarlo
            Producto pProducto = pIterator.next();  

            //se revisa si existe un reporte con la id del producto actual
            Reporte existingReport = reportMap.get(pProducto.getId()); 
            if (existingReport != null) {
                //si existe, se añaden los datos del usuario y sumarle el dinero acumulado
                existingReport.getNombreCliente().add(c.getNombreCompleto());
                existingReport.getCorreoCliente().add(c.getCorreoElectronico());
                existingReport.setPrecioVenta(pProducto.getPrecio() + existingReport.getPrecioVenta());

            } else {
                // si no existe el reporte se crea
                ArrayList<String> nombresClientes = new ArrayList<>();
                nombresClientes.add(c.getNombreCompleto());
                ArrayList<String> correosClientes = new ArrayList<>();
                correosClientes.add(c.getCorreoElectronico());
                Double precio = pProducto.getPrecio();
                switch (pProducto) {
                    case Mouse m -> crearReporte("Mouse",pProducto.getId(), pProducto.getNombre(), nombresClientes, correosClientes, precio);
                    case Audifonos a -> crearReporte("Audifonos",pProducto.getId(), pProducto.getNombre(), nombresClientes, correosClientes, precio);
                    default -> crearReporte("No identificado",pProducto.getId(), pProducto.getNombre(), nombresClientes, correosClientes, precio);
                }

            }
        }
            
    }
    
    
    
    @Override
    public void crearReporte(String tipo,String codigoProducto, String nombreProducto, ArrayList<String> nombreCliente, ArrayList<String> correoCliente, double PrecioVenta) {
        listaReportes.add(new Reporte(tipo ,codigoProducto, nombreProducto, nombreCliente, correoCliente, PrecioVenta));
    }
    
    
    
    
    @Override
    public ArrayList<Reporte> listarReportes() {
        return listaReportes;
    }

    
    
    @Override
    public int cantidadVentas() {
        return listaReportes.size();
    }

    
    
    @Override
    public double montoTotal() {
        double sum = 0;
        for(Reporte r : listaReportes){
            sum += r.getPrecioVenta();
        }
        return sum;
    }
         
}
