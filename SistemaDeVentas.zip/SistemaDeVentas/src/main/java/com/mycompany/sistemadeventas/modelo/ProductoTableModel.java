package com.mycompany.sistemadeventas.modelo;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class ProductoTableModel extends AbstractTableModel {

    private List<Producto> liProductos;
    private String[] columnas={"Tipo","id","Nombre","Marca","Precio","inalambrico","Extra"};
    
    public ProductoTableModel(List<Producto> liProductos){
        this.liProductos=liProductos;
    }
    
    @Override
    public int getRowCount() {
        return liProductos.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Producto producto= liProductos.get(rowIndex);
        String tipo = "";
        if(producto instanceof Mouse){
            tipo = "Mouse";
        }
        else if(producto instanceof Audifonos){
            tipo = "Audifonos";
        }
        switch(columnIndex){
            case 0: return tipo;
            case 1: return producto.getId();
            case 2: return producto.getNombre();
            case 3: return producto.getMarca();
            case 4: return producto.getPrecio();
            case 5: 
                if(producto.isEsInalambrico()){
                    return "Si";
                }else{
                    return "No";
                }
            case 6: 
                if(producto instanceof Mouse m){
                    return m.getCantidadBotones() + " botones";
                }
                else if(producto instanceof Audifonos a){
                    if(a.isMicrofonoIncluido()){
                        return "Mic. incluido";
                    }
                    else{
                        return "Mic. no incluido";
                    }
                }
            default: return null;
        }
    }
    
    
    @Override
    public String getColumnName(int columna){
        return columnas[columna];
    }
    
   
}
