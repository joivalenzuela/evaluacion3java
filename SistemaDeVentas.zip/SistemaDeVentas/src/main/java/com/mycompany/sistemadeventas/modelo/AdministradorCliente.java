  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemadeventas.modelo;

import java.util.ArrayList;
import com.mycompany.sistemadeventas.modelo.interfaces.ClienteDAO;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author jival
 */
public class AdministradorCliente implements ClienteDAO{

    ArrayList<Cliente> listaClientes;

    public AdministradorCliente() {
        listaClientes = new ArrayList<>();
    }
  
    
    
    @Override
     public HashMap<String,Object> agregarCliente(String run, String nombreCompleto, String correoElectronico, String telefono) {
        
        Pattern pattern = Pattern.compile("^[a-zA-ZÀ-ÿ\\u00f1\\u00d1]+(\\s*[a-zA-ZÀ-ÿ\\u00f1\\u00d1]*)*[a-zA-ZÀ-ÿ\\u00f1\\u00d1]+$");
        Matcher matcher = pattern.matcher(nombreCompleto);
        boolean matchFound = matcher.find();
         
        HashMap<String,Object> resuladoAgregar = new HashMap<>();
        
        resuladoAgregar.put("resultado", "nada");
   
        for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
                resuladoAgregar.put("resultado", false);
                resuladoAgregar.put("texto", "El Cliente ingresado ya existe");
            }
        }
        if(!matchFound){
            resuladoAgregar.put("resultado", false);
            resuladoAgregar.put("texto", "El nombre ingresado no es valido");
        }else if(run.length()!=10){
            resuladoAgregar.put("resultado", false);
            resuladoAgregar.put("texto", "El rut ingresado no es valido");
        }
        else if(!correoElectronico.contains("@")){
            resuladoAgregar.put("resultado", false);
            resuladoAgregar.put("texto", "El correo electronico ingresado no es valido");
        }
        
        if(resuladoAgregar.get("resultado").equals("nada")){
            
            resuladoAgregar.put("resultado", true);
            resuladoAgregar.put("texto", "Cliente agregado exitosamente");
            
            Cliente nuevoCliente = new Cliente(run,nombreCompleto,correoElectronico);
            nuevoCliente.setTelefono(telefono);
            listaClientes.add(nuevoCliente);
        }
        return resuladoAgregar;
    }
     
     
     
    @Override
    public boolean eliminarCliente(String run) {
       for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
                listaClientes.remove(c);
                return true;
            }
        }
       return false;
    }

    
    
    @Override
    public HashMap<String,Object> editarCliente(String run, String nombreCompleto, String correoElectronico,  String telefono) {
        Pattern pattern = Pattern.compile("^[a-zA-ZÀ-ÿ\\u00f1\\u00d1]+(\\s*[a-zA-ZÀ-ÿ\\u00f1\\u00d1]*)*[a-zA-ZÀ-ÿ\\u00f1\\u00d1]+$");
        Matcher matcher = pattern.matcher(nombreCompleto);
        boolean matchFound = matcher.find();
        
        HashMap<String,Object> resuladoEditar = new HashMap<>();
        resuladoEditar.put("resultado", "nada");
        for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
                if(!matchFound && nombreCompleto!= ""){
                    resuladoEditar.put("resultado", false);
                    resuladoEditar.put("texto", "El nombre ingresado no es valido.");
                }else if(!correoElectronico.contains("@") && correoElectronico!= ""){
                    resuladoEditar.put("resultado", false);
                    resuladoEditar.put("texto", "El correo electronico ingresado no es valido.");
                }
                else{
                    if(nombreCompleto!= ""){
                        c.setNombreCompleto(nombreCompleto);
                    }
                    if(correoElectronico!= ""){
                        c.setCorreoElectronico(correoElectronico);
                    }
                    if(telefono!= ""){
                        c.setTelefono(telefono);
                    }
                }
                resuladoEditar.put("resultado", true);
                resuladoEditar.put("texto", "Cliente editado correctamente.");
                return resuladoEditar;
            }
        }
        resuladoEditar.put("resultado", false);
        resuladoEditar.put("texto", "El correo electronico ingresado no es valido.");
        return resuladoEditar;
    }
    
   

    @Override
    public ArrayList<Cliente> obtenerClientes() {
        return listaClientes;
    }

    
    
    @Override
    public Cliente buscarCliente(String run) {
        for(Cliente c : listaClientes){
           if(c.getRun().equalsIgnoreCase(run)){
              return c;
           }
        }
        return null;
    }

}    

