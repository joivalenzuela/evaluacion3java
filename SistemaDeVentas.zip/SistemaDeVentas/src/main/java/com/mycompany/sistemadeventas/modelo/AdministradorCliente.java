  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemadeventas.modelo;

import java.util.ArrayList;
import com.mycompany.sistemadeventas.modelo.interfaces.ClienteDAO;

/**
 *
 * @author jival
 */
public class AdministradorCliente implements ClienteDAO{

    ArrayList<Cliente> listaClientes;
   
    @Override
    public String agregarCliente(String run, String nombreCompleto, String correoElectronico) {
        if(run.length()!=10){
            return "El rut ingresado no es valido";
        }
        if(!correoElectronico.contains("@")){
            return "El correo electronico ingresado no es valido";
        }
        for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
                return "El Cliente ingresado ya existe";
            }
        }
        
        Cliente nuevoCliente = new Cliente(run,nombreCompleto,correoElectronico);
        listaClientes.add(nuevoCliente);
        return "Cliente agregado exitosamente";
    }
    
     public String agregarCliente(String run, String nombreCompleto, String correoElectronico, String telefono) {
        if(run.length()!=10){
            return "El rut ingresado no es valido";
        }
        if(!correoElectronico.contains("@")){
            return "El correo electronico ingresado no es valido";
        }
        for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
                return "El Cliente ingresado ya existe";
            }
        }
        
        Cliente nuevoCliente = new Cliente(run,nombreCompleto,correoElectronico);
        nuevoCliente.setTelefono(telefono);
        listaClientes.add(nuevoCliente);
        return "Cliente agregado exitosamente";
    }
    
    
    @Override
    public boolean eliminarCliente(String run) {
       for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
                listaClientes.remove(c);
                return true;
            }
        }
       return false;
    }

    @Override
    public boolean editarCliente(String run, String nombreCompleto, String correoElectronico) {
        for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
               c.setNombreCompleto(nombreCompleto);
               c.setNombreCompleto(nombreCompleto);
               return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean editarCliente(String run, String nombreCompleto, String correoElectronico, String telefono) {
         for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
               c.setNombreCompleto(nombreCompleto);
               c.setNombreCompleto(nombreCompleto);
               c.setTelefono(telefono);
               return true;
            }
        }
        return false;
    }
    

    @Override
    public ArrayList<Cliente> obtenerClientes() {
        return listaClientes;
    }

    @Override
    public Cliente buscarCliente(String run) {
        for(Cliente c : listaClientes){
           if(c.getRun().equalsIgnoreCase(run)){
              return c;
           }
           
        }
        return null;
    }

}    

