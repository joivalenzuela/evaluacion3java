package com.mycompany.sistemadeventas.modelo;

import com.mycompany.sistemadeventas.modelo.interfaces.VentaDAO;
import java.util.ArrayList;
import java.util.HashMap;


public class AdministradorVenta implements VentaDAO{
    
    ArrayList<Venta> listaVentas;
    private ArrayList<Producto> carro;
    
    public AdministradorVenta() {
        carro = new ArrayList<Producto>();
        listaVentas = new ArrayList<Venta>();
    }
    

    @Override
    public HashMap<String,Object> realizarVenta(Cliente c, double pago) {
        
        Venta venta = new Venta(c);
        venta.setProductos(carro);
        HashMap<String,Object> resultadoVenta = new HashMap<>();
        double precioTotal = 0;
        for(Producto producto : carro){
            precioTotal += producto.getPrecio();
        }
        if(pago<0){
            setResult(resultadoVenta, false, "Valor de Pago invalido");
        }else if(precioTotal == pago){
            setResult(resultadoVenta, true, "Venta realizada Satisfactoriamente",0);
        }else if(precioTotal < pago){
            setResult(resultadoVenta, true, "Venta realizada Satisfactoriamente",pago-precioTotal);
        }else{
            setResult(resultadoVenta, false, "Monto Insuficiente");
        }
        if(resultadoVenta.get("resultado").equals(true)){
            listaVentas.add(venta);
        }
        return resultadoVenta;
    }
    
    private void setResult(HashMap<String, Object> resultMap, boolean success, String message) {
            resultMap.put("resultado", success);
            resultMap.put("texto", message);
        }
    private void setResult(HashMap<String, Object> resultMap, boolean success, String message, double money) {
            resultMap.put("resultado", success);
            resultMap.put("texto", message);
            resultMap.put("vuelto",money);
        }

    @Override
    public boolean agregarCarro(Producto producto) {
       for(Producto p : carro){
           if(p.getId().equalsIgnoreCase(producto.getId())){
               return false;
           }
       }
       carro.add(producto);
       return true;
    }

    @Override
    public void limpiarCarro() {
        carro = new ArrayList<>();
    }

    @Override
    public ArrayList<Producto> obtenerCarro() {
        return carro;
    }

    @Override
    public double costoCarro() {
        double sum = 0;
        for(Producto p : carro){
            sum+=p.getPrecio();
        }
        return sum;
    }

    @Override
    public boolean eliminarDelCarro(String id) {
        for(Producto p : carro){
           if(p.getId().equalsIgnoreCase(id)){
               carro.remove(p);
               return true;
           }
       }
       return false;
    }

   
    
    
}
