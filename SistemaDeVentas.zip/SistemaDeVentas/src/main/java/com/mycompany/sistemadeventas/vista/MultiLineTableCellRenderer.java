package com.mycompany.sistemadeventas.vista;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;


public class MultiLineTableCellRenderer extends JList<String> implements TableCellRenderer {

    public MultiLineTableCellRenderer() {
        setOpaque(true);
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setLayoutOrientation(JList.VERTICAL);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        
        if (value instanceof String[]) {
            String[] stringArray = (String[]) value;
            setListData(stringArray); 

           
            int rowHeight = stringArray.length * 18; 
            table.setRowHeight(row, rowHeight); 

            
            if (isSelected) {
                setBackground(table.getSelectionBackground());
                setForeground(table.getSelectionForeground());
            } else {
                setBackground(table.getBackground());
                setForeground(table.getForeground());
            }
        }

        return this;
    }

     @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Get the graphics object, and cast it to Graphics2D for more control
        Graphics2D g2d = (Graphics2D) g;

        // Calculate the height of each item in the list (you can adjust this based on your preferences)
        int itemHeight = 18; // This corresponds to the row height you set in getTableCellRendererComponent
        int itemCount = getModel().getSize(); // Number of items in the JList
        int width = getWidth(); // Width of the cell

        // Draw horizontal lines between the items
        g2d.setColor(Color.DARK_GRAY); // Set line color

        // Loop through the items and draw a line after each item except the last one
        for (int i = 1; i < itemCount; i++) {
            int yPosition = i * itemHeight;
            g2d.drawLine(0, yPosition, width, yPosition);
        }
    }
    

    
    
}