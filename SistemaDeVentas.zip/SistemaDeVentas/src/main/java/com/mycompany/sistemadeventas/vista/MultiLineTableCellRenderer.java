package com.mycompany.sistemadeventas.vista;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;

public class MultiLineTableCellRenderer extends JList<String> implements TableCellRenderer {

    public MultiLineTableCellRenderer() {
        setOpaque(true);
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setLayoutOrientation(JList.VERTICAL);
        setVisibleRowCount(-1); 
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        if (value instanceof String[]) {
            String[] stringArray = (String[]) value;
            setListData(stringArray); 

           
            int rowHeight = stringArray.length * 18; 
            table.setRowHeight(row, rowHeight); 

            
            if (isSelected) {
                setBackground(table.getSelectionBackground());
                setForeground(table.getSelectionForeground());
            } else {
                setBackground(table.getBackground());
                setForeground(table.getForeground());
            }
        }

        return this;
    }
}