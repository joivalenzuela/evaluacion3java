package com.mycompany.sistemadeventas.modelo.interfaces;

import com.mycompany.sistemadeventas.modelo.Cliente;
import com.mycompany.sistemadeventas.modelo.Producto;
import com.mycompany.sistemadeventas.modelo.Reporte;
import java.util.ArrayList;

public interface ReporteDAO {
    
    void reportarVenta(Cliente c,ArrayList<Producto> carro);
    void crearReporte(String tipo,String codigoProducto,String nombreProducto,ArrayList<String> nombreCliente,ArrayList<String> correoCliente,double PrecioVenta);
    
    ArrayList<Reporte> listarReportes();
   
    int cantidadVentas();
    
    double montoTotal();
    
}
