package com.mycompany.sistemadeventas.modelo.interfaces;

public interface ReporteDAO {
    
    void crearReporte(String codigoProducto,String nombreProducto,String nombreCliente,String correoCliente,double PrecioVenta);
    
    void listarReportes();
   
    int cantidadVentas();
    
    double montoTotal();
    
}
