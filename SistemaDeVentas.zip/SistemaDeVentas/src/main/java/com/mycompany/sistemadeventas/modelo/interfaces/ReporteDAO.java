package com.mycompany.sistemadeventas.modelo.interfaces;

import com.mycompany.sistemadeventas.modelo.Reporte;
import java.util.ArrayList;

public interface ReporteDAO {
    
    void crearReporte(String codigoProducto,String nombreProducto,String nombreCliente,String correoCliente,double PrecioVenta);
    
    ArrayList<Reporte> listarReportes();
   
    int cantidadVentas();
    
    double montoTotal();
    
}
