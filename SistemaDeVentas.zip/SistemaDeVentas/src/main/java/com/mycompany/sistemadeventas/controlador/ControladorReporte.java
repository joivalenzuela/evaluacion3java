package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.ReporteTableModel;
import com.mycompany.sistemadeventas.modelo.interfaces.ReporteDAO;
import com.mycompany.sistemadeventas.vista.FrameReporte;
import java.awt.event.ActionEvent;

public class ControladorReporte {
    private FrameReporte vistaReporte;
    private ReporteDAO reporteDao;

    public ControladorReporte(FrameReporte vistaReporte,ReporteDAO reporteDao) {
        this.vistaReporte = vistaReporte;
        this.reporteDao = reporteDao;
        vistaReporte.getLblVentasTotales().setText(String.valueOf(0));
        vistaReporte.getLblGananciasTotales().setText(String.valueOf(0));
        agregarListeners();
    }

    private void agregarListeners() {
        
        //funcionalidad boton recargar
        vistaReporte.getBtnRecargar().addActionListener((ActionEvent e) -> {
            ReporteTableModel modeloTablaReporte = new ReporteTableModel(reporteDao.listarReportes());
            vistaReporte.actualizarTablaReporte(modeloTablaReporte);
            
            vistaReporte.getLblVentasTotales().setText(String.valueOf(reporteDao.cantidadVentas()));
            vistaReporte.getLblGananciasTotales().setText(String.valueOf(reporteDao.montoTotal()));
        });
    }
}
