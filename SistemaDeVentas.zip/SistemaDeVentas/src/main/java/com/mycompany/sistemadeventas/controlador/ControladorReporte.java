package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.AdministradorReporte;
import com.mycompany.sistemadeventas.modelo.interfaces.ReporteDAO;
import com.mycompany.sistemadeventas.vista.FrameReporte;

public class ControladorReporte {
    private FrameReporte vistaReporte;
    private ReporteDAO reporteDao;

    public ControladorReporte(FrameReporte vistaReporte) {
        this.vistaReporte = vistaReporte;
        reporteDao = new AdministradorReporte();
        agregarListeners();
    }

    private void agregarListeners() {
    }

   
    
}
