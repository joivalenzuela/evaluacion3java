package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.AdministradorReporte;
import com.mycompany.sistemadeventas.modelo.ReporteTableModel;
import com.mycompany.sistemadeventas.modelo.interfaces.ReporteDAO;
import com.mycompany.sistemadeventas.vista.FrameReporte;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorReporte {
    private FrameReporte vistaReporte;
    private ReporteDAO reporteDao;

    public ControladorReporte(FrameReporte vistaReporte,ReporteDAO reporteDao) {
        this.vistaReporte = vistaReporte;
        this.reporteDao = reporteDao;
        agregarListeners();
    }

    private void agregarListeners() {
        vistaReporte.getBtnRecargar().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ReporteTableModel modeloTablaReporte = new ReporteTableModel(reporteDao.listarReportes());
                vistaReporte.actualizarTablaReporte(modeloTablaReporte);
                
                vistaReporte.getLblVentasTotales().setText(String.valueOf(reporteDao.cantidadVentas()));
                vistaReporte.getLblGananciasTotales().setText(String.valueOf(reporteDao.montoTotal()));
            }
        });
        
    }
}
