package com.mycompany.sistemadeventas.modelo.interfaces;

import com.mycompany.sistemadeventas.modelo.Cliente;
import java.util.ArrayList;
import java.util.HashMap;

public interface ClienteDAO {
    
 
    HashMap<String,Object> agregarCliente(String run, String nombreCompleto,String correoElectronico,String telefono);
    
    boolean eliminarCliente(String run);
   
    HashMap<String,Object> editarCliente(String run, String nombreCompleto,String correoElectronico, String telefono);
   
    ArrayList<Cliente> obtenerClientes();
    
    Cliente buscarCliente(String run);
}
