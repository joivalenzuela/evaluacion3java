package com.mycompany.sistemadeventas.modelo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;


public class Venta {
    private Cliente cliente;
    private ArrayList<Producto> productos;
    private LocalDate fecha;
    private LocalTime hora;

    public Venta() {
        fecha = LocalDate.now();
        hora  = LocalTime.now();      
    }

    public Venta(Cliente cliente) {
        this.cliente = cliente;
        fecha = LocalDate.now();
        hora  = LocalTime.now();  
    }


    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }


 
    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public ArrayList getProductos() {
        return productos;
    }

    public void setProductos(ArrayList productos) {
        this.productos = productos;
    }
    
}
