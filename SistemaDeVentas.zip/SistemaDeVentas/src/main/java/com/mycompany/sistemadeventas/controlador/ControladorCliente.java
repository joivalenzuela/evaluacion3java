package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.AdministradorCliente;
import com.mycompany.sistemadeventas.modelo.Cliente;
import com.mycompany.sistemadeventas.modelo.ClienteTableModel;
import com.mycompany.sistemadeventas.modelo.interfaces.ClienteDAO;
import com.mycompany.sistemadeventas.vista.FrameCliente;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;


public class ControladorCliente {
    private FrameCliente vistaCliente;
    private ClienteDAO clienteDao;

    public ControladorCliente(FrameCliente vistaCliente,ClienteDAO clienteDao) {
        this.vistaCliente = vistaCliente;
        this.clienteDao= clienteDao;
        agregarListeners();
    }
    private void agregarListeners(){
  
        vistaCliente.getBtnAgregar().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
                String nombre= vistaCliente.getTxtNombreCompleto().getText();
                String rut= vistaCliente.getTxtRut().getText();
                String email= vistaCliente.getTxtEmail().getText();
                String telefono= vistaCliente.getTxtTelefono().getText();
                
                //respuesta retorna con 2 llaves, "resultado" que es un boleano que determina si se pudo agregar o no el cliente
                // y "texto" que es una String con el texto que se debe mostrar al usuario en cada situacion
                HashMap <String,Object> respuesta = clienteDao.agregarCliente(rut, nombre, email, telefono);
                
                if((boolean)respuesta.get("resultado")){
                    vistaCliente.mensajeUsuariOColorExito();
                    vistaCliente.actualizarInfoUsuario((String)respuesta.get("texto"));
                    ClienteTableModel modeloTablaCliente= new ClienteTableModel(clienteDao.obtenerClientes());
                    vistaCliente.actualizarTablaClientes(modeloTablaCliente);
                    vistaCliente.getTxtNombreCompleto().setText("");
                    vistaCliente.getTxtRut().setText("");
                    vistaCliente.getTxtEmail().setText("");
                    vistaCliente.getTxtTelefono().setText("");
                }else{
                    vistaCliente.mensajeUsuariOColorError();
                    vistaCliente.actualizarInfoUsuario((String)respuesta.get("texto"));
                }
                
            }
            
        });
        vistaCliente.getBtnEditar().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre= vistaCliente.getTxtNombreCompleto().getText();
                String rut= vistaCliente.getTxtRut().getText();
                String email= vistaCliente.getTxtEmail().getText();
                String telefono= vistaCliente.getTxtTelefono().getText();
                
              
                //si se eliman estos if el metodo no funciona correctamente, no estoy muy seguro porque, pero no hay que eliminarlo.
                if(nombre.isEmpty()){
                    nombre = "";
                }
                if(email.isEmpty()){
                    email = "";
                }
                if(telefono.isEmpty()){
                    telefono = "";
                }
                
                //respuesta retorna con 2 llaves, "resultado" que es un boleano que determina si se pudo agregar o no el cliente
                // y "texto" que es una String con el texto que se debe mostrar al usuario en cada situacion
                HashMap<String,Object> respuesta=clienteDao.editarCliente(rut, nombre, email, telefono);
               
                if((boolean)respuesta.get("resultado")){
                    vistaCliente.mensajeUsuariOColorExito();
                    vistaCliente.actualizarInfoUsuario((String)respuesta.get("texto"));
                }else{
                    vistaCliente.mensajeUsuariOColorError();
                    vistaCliente.actualizarInfoUsuario((String)respuesta.get("texto"));
                }
                ClienteTableModel modeloTablaCliente= new ClienteTableModel(clienteDao.obtenerClientes());
                vistaCliente.actualizarTablaClientes(modeloTablaCliente);
                
            }
                
            
            
        });
        
        vistaCliente.getBtnBuscar().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
              
                String rut= vistaCliente.getTxtRut().getText();
                
                Cliente cliente=clienteDao.buscarCliente(rut);
                
                if(cliente!=null){
                    vistaCliente.mensajeUsuariOColorExito();
                    vistaCliente.actualizarInfoUsuario("Cliente Encontrado");
                    vistaCliente.getTxtNombreCompleto().setText(cliente.getNombreCompleto());
                    vistaCliente.getTxtEmail().setText(cliente.getCorreoElectronico());
                    vistaCliente.getTxtTelefono().setText(cliente.getTelefono());
                
                }else{
                    vistaCliente.mensajeUsuariOColorError();
                    vistaCliente.actualizarInfoUsuario("El cliente no fue encontrado");
                }
            
            }
        });
        
        
        vistaCliente.getBtnEliminar().addActionListener(new ActionListener(){
       
            @Override
            public void actionPerformed(ActionEvent e) {
                String rut= vistaCliente.getTxtRut().getText();
                Cliente cliente=clienteDao.buscarCliente(rut);
                if(clienteDao.eliminarCliente(rut)){
                    vistaCliente.mensajeUsuariOColorExito();
                    vistaCliente.actualizarInfoUsuario("Cliente Eliminado");
                    ClienteTableModel modeloTablaCliente= new ClienteTableModel(clienteDao.obtenerClientes());
                    vistaCliente.actualizarTablaClientes(modeloTablaCliente);
                }else{
                    vistaCliente.mensajeUsuariOColorError();
                    vistaCliente.actualizarInfoUsuario("El cliente no fue encontrado");
                }
            }
        });
        
    }
    }
