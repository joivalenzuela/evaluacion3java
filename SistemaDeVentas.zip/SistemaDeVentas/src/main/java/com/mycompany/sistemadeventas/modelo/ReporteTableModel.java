package com.mycompany.sistemadeventas.modelo;

import javax.swing.table.AbstractTableModel;
import java.util.List;

public class ReporteTableModel extends AbstractTableModel {

    private List<Reporte> liReportes;
    private String[] columnas = {"Nombre Cliente", "Correo Cliente", "IDs Productos", "Nombres Productos", "Pago"};

    public ReporteTableModel(List<Reporte> liReportes) {
        this.liReportes = liReportes;
    }

    @Override
    public int getRowCount() {
        return liReportes.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Reporte reporte = liReportes.get(rowIndex);

        switch (columnIndex) {
            case 0:
                return reporte.getNombreCliente(); 
            case 1:
                return reporte.getCorreoCliente();
            case 2:
                return reporte.getCodigoProducto(); 
            case 3:
                return reporte.getNombreProducto(); 
            case 4:
                return String.valueOf(reporte.getPrecioVenta()); 
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columna) {
        return columnas[columna];
    }

    @Override
    public Class getColumnClass(int c) {
      
        if (c == 2 || c == 3) {
            return String[].class;
        }
        return getValueAt(0, c).getClass(); 
    }
}

