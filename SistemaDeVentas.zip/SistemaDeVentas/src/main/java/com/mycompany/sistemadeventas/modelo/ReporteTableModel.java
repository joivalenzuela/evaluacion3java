package com.mycompany.sistemadeventas.modelo;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import java.util.List;

public class ReporteTableModel extends AbstractTableModel {

    private List<Reporte> liReportes;
    private String[] columnas = {"Tipo","IDs Producto", "Nombre Producto","Nombre Clientes", "Correo Clientes",  "Acumulado"};

    public ReporteTableModel(List<Reporte> liReportes) {
        this.liReportes = liReportes;
    }

    @Override
    public int getRowCount() {
        return liReportes.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Reporte reporte = liReportes.get(rowIndex);

        switch (columnIndex) {
            
            case 0:
                return reporte.getTipo();
            case 1:
                return reporte.getCodigoProducto(); 
            case 2:
                return reporte.getNombreProducto(); 
            case 3:
                return listaHaciaArray(reporte.getNombreCliente()); 
            case 4:
                return listaHaciaArray(reporte.getCorreoCliente());
            case 5:
                return "$ ".concat(String.valueOf(reporte.getPrecioVenta())); 
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columna) {
        return columnas[columna];
    }

    @Override
    public Class getColumnClass(int c) {
      
        if (c == 2 || c == 3) {
            return String[].class;
        }
        return getValueAt(0, c).getClass(); 
    }
    
    private String[] listaHaciaArray(ArrayList<String> aL){
      int tamaño = aL.size();
      String[] nuevo = new String[tamaño];
      for(int i = 0;i!=tamaño;i++){
          nuevo[i] = aL.get(i);
      }
      return nuevo;
    }
}

