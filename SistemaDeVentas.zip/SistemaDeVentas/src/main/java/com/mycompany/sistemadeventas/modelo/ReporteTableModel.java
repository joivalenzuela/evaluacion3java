package com.mycompany.sistemadeventas.modelo;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class ReporteTableModel extends AbstractTableModel {

    private List<Reporte> liReportes;
    private String[] columnas={"Nombre Cliente","Correo Cliente","IDs Productos","Nombres Productos","Pago"};
    
    public ReporteTableModel(List<Reporte> liReportes){
        this.liReportes=liReportes;
    }
    
    @Override
    public int getRowCount() {
        return liReportes.size();
    }

    @Override
    public int getColumnCount() {
        return columnas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Reporte reporte= liReportes.get(rowIndex);
        
       
        switch(columnIndex){
            case 0: return reporte.getNombreCliente();
            case 1: return reporte.getCorreoCliente();
            case 2: return listasAString((reporte.getCodigoProducto()));
            case 3: return listasAString((reporte.getNombreProducto()));
            case 4: return reporte.getPrecioVenta();
  
            default: return null;
        }
    }
    
    
    @Override
    public String getColumnName(int columna){
        return columnas[columna];
    }
    
    public String listasAString(ArrayList<String> lista){
        String resultado = "";
        for(String s : lista){
            resultado = resultado + s + "/";
        }
        return resultado;
    }
}
