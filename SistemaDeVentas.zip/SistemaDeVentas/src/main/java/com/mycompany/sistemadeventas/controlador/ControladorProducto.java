package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.Audifonos;
import com.mycompany.sistemadeventas.modelo.AudifonosTableModel;
import com.mycompany.sistemadeventas.modelo.Mouse;
import com.mycompany.sistemadeventas.modelo.MouseTableModel;
import com.mycompany.sistemadeventas.modelo.Producto;
import com.mycompany.sistemadeventas.modelo.ProductoTableModel;
import com.mycompany.sistemadeventas.modelo.interfaces.ProductoDAO;
import com.mycompany.sistemadeventas.vista.FrameProducto;
import java.awt.event.ActionEvent;
import java.util.HashMap;

 
public class ControladorProducto {
    private FrameProducto vistaProducto;
    private ProductoDAO productoDao;
    
    public ControladorProducto(FrameProducto vistaProducto,ProductoDAO productoDao) {
        this.vistaProducto = vistaProducto;
        this.productoDao = productoDao;
        vistaProducto.getPanelCantidadBotones().setVisible(true);
        vistaProducto.getPanelMicrofonoIncluido().setVisible(false);
        agregarListeners();
    }
    
    private void agregarListeners(){
        
        //funcionalidad radio button mouse (tipo producto)
        vistaProducto.getjRbMouse().addActionListener((ActionEvent e) -> {
            vistaProducto.getPanelCantidadBotones().setVisible(true);
            vistaProducto.getPanelMicrofonoIncluido().setVisible(false);
        });   
        
        //funcionalidad radio button audifonos (tipo producto)
        vistaProducto.getjRbAudiofonos().addActionListener((ActionEvent e) -> {        
            vistaProducto.getPanelCantidadBotones().setVisible(false);
            vistaProducto.getPanelMicrofonoIncluido().setVisible(true);
        });  
          
        //funcionalidad boton agregar
        vistaProducto.getBtnAgregarProducto().addActionListener((ActionEvent e) -> {
            boolean inalambrico = true;
            double precio = 0;
            HashMap<String,Object> respuestaAgregar;
            
            String id = vistaProducto.getTxtId().getText();
            String nombre = vistaProducto.getTxtNombre().getText();
            String marca = vistaProducto.getTxtMarca().getText();
            
            if(!vistaProducto.getTxtPrecio().getText().equalsIgnoreCase("")){
                precio = Double.parseDouble(vistaProducto.getTxtPrecio().getText());
            }
            if(vistaProducto.getjRbNo().isSelected()){
                inalambrico = false;
            }
            
            if(vistaProducto.getjRbMouse().isSelected()){
                respuestaAgregar = agregarProducto("m", id, nombre, marca, precio, inalambrico);
                if((boolean)respuestaAgregar.get("resultado")){
                    actualizarTablas("m");
                    resetearCampos();
                }
            }
            else if(vistaProducto.getjRbAudiofonos().isSelected()){
                respuestaAgregar = agregarProducto("a", id, nombre, marca, precio, inalambrico);
                if((boolean)respuestaAgregar.get("resultado")){
                    actualizarTablas("a");
                    resetearCampos();
                }
            }
            else{
                return;
            }
            vistaProducto.actualizarInfoProducto((String)respuestaAgregar.get("texto"));
            vistaProducto.getTbProductos().repaint();
        });
        
        //funcionalidad radio button tabla general (modo de vista)       
        vistaProducto.getRbVistaTablaGeneral().addActionListener((ActionEvent e) -> {
            vistaProducto.getpTbFiltrada().setVisible(false);
            vistaProducto.getPanelTablaGeneral().setVisible(true);
        });
        
        //funcionalidad radio button tablas filtradas (modo de vista)       
        vistaProducto.getRbVistaTablasFiltradas().addActionListener((ActionEvent e) -> {
            vistaProducto.getpTbFiltrada().setVisible(true);
            vistaProducto.getPanelTablaGeneral().setVisible(false);
        });
        
        //funcionalidad boton buscar       
        vistaProducto.getBtnBuscarProducto().addActionListener((ActionEvent e) -> {
            String id =  vistaProducto.getTxtId().getText();
            Producto producto = productoDao.buscarProducto(id);
            
            if(producto == null){
                vistaProducto.actualizarInfoProducto("Producto no encontrado");
                return;
            }
            
            vistaProducto.actualizarInfoProducto("Producto encontrado");
            vistaProducto.getTxtNombre().setText(producto.getNombre());
            vistaProducto.getTxtMarca().setText(producto.getMarca());
            vistaProducto.getTxtPrecio().setText((Double.toString(producto.getPrecio())));

            if(producto.isEsInalambrico()){
                vistaProducto.getjRbNo().setSelected(false);
                vistaProducto.getjRbSi().setSelected(true);
            }else{
                vistaProducto.getjRbNo().setSelected(true);
                vistaProducto.getjRbSi().setSelected(false);
            }
            switch (producto) {
                case Mouse m -> {
                    vistaProducto.getPanelCantidadBotones().setVisible(true);
                    vistaProducto.getPanelMicrofonoIncluido().setVisible(false);
                    vistaProducto.getMedidorCantidadBotones().setValue(m.getCantidadBotones());
                    vistaProducto.getjRbMouse().setSelected(true);
                }
                case Audifonos a -> {    
                    vistaProducto.getPanelCantidadBotones().setVisible(false);
                    vistaProducto.getPanelMicrofonoIncluido().setVisible(true);
                    vistaProducto.getjRbAudiofonos().setSelected(true);
                    if(a.isMicrofonoIncluido()){
                        vistaProducto.getjCheckBoxMicroIncluido().setSelected(true);
                    }else{
                        vistaProducto.getjCheckBoxMicroIncluido().setSelected(false);
                    }

                }
                default -> {
                }
            }
            
        });
    }
    
    
    //metodo que dependiendo del tipo de producto llama su metodo correspondiente para registrarlo
    private HashMap<String,Object> agregarProducto(String modo, String id, String nombre, String marca, double precio, boolean inalambrico){
        
        HashMap<String,Object> respuesta;
        switch (modo) {
            case "m" -> {
                int cantidadBotones = (int)vistaProducto.getMedidorCantidadBotones().getValue();
                respuesta = productoDao.registrarProducto(new Mouse(cantidadBotones, id, nombre,  marca, precio, inalambrico));
                return respuesta;
            }
            case "a" -> {
                boolean microfono = (boolean)vistaProducto.getjCheckBoxMicroIncluido().isSelected();
                respuesta = productoDao.registrarProducto(new Audifonos(microfono, id, nombre,  marca, precio, inalambrico));
                return respuesta;
            }
            default -> {
                return null;
            }
        }
       
    }
    
    
    
    private void actualizarTablas(String modo){
        if("m".equals(modo)){
                MouseTableModel modeloTablaMouse = new MouseTableModel(productoDao.obtenerProductos("m"));
                vistaProducto.actualizarTablaMouse(modeloTablaMouse);
            }
        if("a".equals(modo)){
            AudifonosTableModel modeloTablaAudifonos1= new AudifonosTableModel(productoDao.obtenerProductos("a"));
            vistaProducto.actualizarTablaAudifono(modeloTablaAudifonos1);
        }
        ProductoTableModel modeloTablaProducto = new ProductoTableModel(productoDao.obtenerProductos());
        vistaProducto.actualizarTablaProducto(modeloTablaProducto);
    }
    
    
    
    private void resetearCampos(){
        vistaProducto.getTxtId().setText("");
        vistaProducto.getTxtNombre().setText("");
        vistaProducto.getTxtMarca().setText("");
        vistaProducto.getTxtPrecio().setText("");
        vistaProducto.getjRbNo().setSelected(false);
        vistaProducto.getjRbSi().setSelected(true);
    }
    
}
