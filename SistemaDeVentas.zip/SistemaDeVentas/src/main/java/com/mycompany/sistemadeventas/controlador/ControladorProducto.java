package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.AdministradorProducto;
import com.mycompany.sistemadeventas.modelo.interfaces.ProductoDAO;
import com.mycompany.sistemadeventas.vista.FrameProducto;


public class ControladorProducto {
    private FrameProducto vistaProducto;
    private ProductoDAO productoDao;

    public ControladorProducto(FrameProducto vistaProducto) {
        this.vistaProducto = vistaProducto;
        productoDao = new AdministradorProducto();
        agregarListeners();
    }
    
    private void agregarListeners(){
      //TODO agregar funcionalidad a vistaproducto
    }
    
    
}
