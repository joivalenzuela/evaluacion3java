package com.mycompany.sistemadeventas.controlador;

import com.mycompany.sistemadeventas.modelo.AdministradorProducto;
import com.mycompany.sistemadeventas.modelo.Audifonos;
import com.mycompany.sistemadeventas.modelo.AudifonosTableModel;
import com.mycompany.sistemadeventas.modelo.Mouse;
import com.mycompany.sistemadeventas.modelo.MouseTableModel;
import com.mycompany.sistemadeventas.modelo.Producto;
import com.mycompany.sistemadeventas.modelo.ProductoTableModel;
import com.mycompany.sistemadeventas.modelo.interfaces.ProductoDAO;
import com.mycompany.sistemadeventas.vista.FrameProducto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;


public class ControladorProducto {
    private FrameProducto vistaProducto;
    private ProductoDAO productoDao;
    private int modo;
    
    public ControladorProducto(FrameProducto vistaProducto,ProductoDAO productoDao) {
        this.vistaProducto = vistaProducto;
        this.productoDao = productoDao;
        vistaProducto.getPanelCantidadBotones().setVisible(true);
        vistaProducto.getPanelMicrofonoIncluido().setVisible(false);
        agregarListeners();
    }
    
    private void agregarListeners(){
        vistaProducto.getjRbMouse().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modo = 0;
                
                vistaProducto.getPanelCantidadBotones().setVisible(true);
                vistaProducto.getPanelMicrofonoIncluido().setVisible(false);
            }
          });   
        
        vistaProducto.getjRbAudiofonos().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modo = 1;
                vistaProducto.getPanelCantidadBotones().setVisible(false);
                vistaProducto.getPanelMicrofonoIncluido().setVisible(true);
                 
            }
          });  
          
        vistaProducto.getBtnAgregarProducto().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean inalambrico = true;
                double precio = 0;
                String id = vistaProducto.getTxtId().getText();
                String nombre = vistaProducto.getTxtNombre().getText();
                String marca = vistaProducto.getTxtMarca().getText();
                String preciotxt = vistaProducto.getTxtPrecio().getText();
                
                if(!vistaProducto.getTxtPrecio().getText().equalsIgnoreCase("")){
                    precio = Double.parseDouble(vistaProducto.getTxtPrecio().getText());
                }
              
                if(vistaProducto.getjRbNo().isSelected()){
                    inalambrico = false;
                }
                        
                        
                if(modo == 0){
                    int cantidadBotones = (int)vistaProducto.getMedidorCantidadBotones().getValue();  
                    HashMap<String,Object> respuesta = productoDao.registrarProducto(new Mouse(cantidadBotones, id, nombre,  marca, precio, inalambrico));
                    
                    if((boolean)respuesta.get("resultado")){
                        vistaProducto.actualizarInfoProducto((String)respuesta.get("texto"));
                        MouseTableModel modeloTablaMouse = new MouseTableModel(productoDao.obtenerProductos("m"));
                        vistaProducto.actualizarTablaMouse(modeloTablaMouse);
                        
                        ProductoTableModel modeloTablaProducto = new ProductoTableModel(productoDao.obtenerProductos());
                        vistaProducto.actualizarTablaProducto(modeloTablaProducto);
                        
                        vistaProducto.getTxtId().setText("");
                        vistaProducto.getTxtNombre().setText("");
                        vistaProducto.getTxtMarca().setText("");
                        vistaProducto.getTxtPrecio().setText("");
                        vistaProducto.getjRbNo().setSelected(false);
                        vistaProducto.getjRbSi().setSelected(true);
                    }else{
                        vistaProducto.actualizarInfoProducto((String)respuesta.get("texto"));
                    }
                           
                }
                
                if(modo == 1){
                    boolean microfono = (boolean)vistaProducto.getjCheckBoxMicroIncluido().isSelected();  
                    HashMap<String,Object> respuesta = productoDao.registrarProducto(new Audifonos(microfono, id, nombre,  marca, precio, inalambrico));
                    
                    if((boolean)respuesta.get("resultado")){
                        vistaProducto.actualizarInfoProducto((String)respuesta.get("texto"));
                        AudifonosTableModel modeloTablaAudifonos1= new AudifonosTableModel(productoDao.obtenerProductos("a"));
                        vistaProducto.actualizarTablaAudifono(modeloTablaAudifonos1);
                        
                        ProductoTableModel modeloTablaProducto = new ProductoTableModel(productoDao.obtenerProductos());
                        vistaProducto.actualizarTablaProducto(modeloTablaProducto);
                        
                        vistaProducto.getTxtId().setText("");
                        vistaProducto.getTxtNombre().setText("");
                        vistaProducto.getTxtMarca().setText("");
                        vistaProducto.getTxtPrecio().setText("");
                        vistaProducto.getjRbNo().setSelected(false);
                        vistaProducto.getjRbSi().setSelected(true);
                    }else{
                        vistaProducto.actualizarInfoProducto((String)respuesta.get("texto"));
                    }
                }
                vistaProducto.getTbProductos().repaint();
               
                
            }
        });
        vistaProducto.getRbVistaTablaGeneral().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                
                vistaProducto.getpTbFiltrada().setVisible(false);
                vistaProducto.getPanelTablaGeneral().setVisible(true);
                
                
            }
        });
        vistaProducto.getRbVistaTablasFiltradas().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                vistaProducto.getpTbFiltrada().setVisible(true);
                vistaProducto.getPanelTablaGeneral().setVisible(false);
                
                
            }
        });
        
        vistaProducto.getBtnBuscarProducto().addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                String id =  vistaProducto.getTxtId().getText();
                Producto producto = productoDao.buscarProducto(id);
                
                if(producto != null){
                    vistaProducto.actualizarInfoProducto("Producto encontrado");
                    vistaProducto.getTxtNombre().setText(producto.getNombre());
                    vistaProducto.getTxtMarca().setText(producto.getMarca());
                    vistaProducto.getTxtPrecio().setText((Double.toString(producto.getPrecio())));
                    
                    if(producto.isEsInalambrico()){
                        vistaProducto.getjRbNo().setSelected(false);
                        vistaProducto.getjRbSi().setSelected(true);
                    }else{
                        vistaProducto.getjRbNo().setSelected(true);
                        vistaProducto.getjRbSi().setSelected(false);
                    }
                    if(producto instanceof Mouse m){
                        vistaProducto.getMedidorCantidadBotones().setValue(m.getCantidadBotones());
                    }
                    else if(producto instanceof Audifonos a){
                        if(a.isMicrofonoIncluido()){
                            vistaProducto.getjCheckBoxMicroIncluido().setSelected(true);
                        }else{
                            vistaProducto.getjCheckBoxMicroIncluido().setSelected(false);
                        }
                    }
                }else{
                    vistaProducto.actualizarInfoProducto("Producto no encontrado");
                }
            }
        });
    }
    
    
}
