package com.mycompany.sistemadeventas.modelo;

import java.util.ArrayList;


public class Reporte {
    private String tipo;
    private String codigoProducto;
    private String nombreProducto;
    private ArrayList<String> nombreCliente;
    private ArrayList<String> correoCliente;
    private double PrecioVenta;

    public Reporte( String tipo,String codigoProducto, String nombreProducto, ArrayList<String> nombreCliente, ArrayList<String> correoCliente, double PrecioVenta) {
        this.codigoProducto = codigoProducto;
        this.nombreProducto = nombreProducto;
        this.nombreCliente = nombreCliente;
        this.correoCliente = correoCliente;
        this.PrecioVenta = PrecioVenta;
        this.tipo = tipo;
    }

    public String getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(String codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public ArrayList<String> getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(ArrayList<String> nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public ArrayList<String> getCorreoCliente() {
        return correoCliente;
    }

    public void setCorreoCliente(ArrayList<String> correoCliente) {
        this.correoCliente = correoCliente;
    }

    public double getPrecioVenta() {
        return PrecioVenta;
    }

    public void setPrecioVenta(double PrecioVenta) {
        this.PrecioVenta = PrecioVenta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
    
    
    
}
