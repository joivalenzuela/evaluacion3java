package com.mycompany.sistemadeventas.modelo;

import java.util.ArrayList;


public class Reporte {
    private ArrayList<String> codigoProducto;
    private ArrayList<String> nombreProducto;
    private String nombreCliente;
    private String correoCliente;
    private double PrecioVenta;

    public Reporte(ArrayList<String> codigoProducto, ArrayList<String> nombreProducto, String nombreCliente, String correoCliente, double PrecioVenta) {
        this.codigoProducto = codigoProducto;
        this.nombreProducto = nombreProducto;
        this.nombreCliente = nombreCliente;
        this.correoCliente = correoCliente;
        this.PrecioVenta = PrecioVenta;
    }

    public ArrayList<String> getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(ArrayList<String> codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public ArrayList<String> getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(ArrayList<String> nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getCorreoCliente() {
        return correoCliente;
    }

    public void setCorreoCliente(String correoCliente) {
        this.correoCliente = correoCliente;
    }

    public double getPrecioVenta() {
        return PrecioVenta;
    }

    public void setPrecioVenta(double PrecioVenta) {
        this.PrecioVenta = PrecioVenta;
    }
    
    
    
    
    
}
