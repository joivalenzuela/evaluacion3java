/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.sistemadeventas.modelo.interfaces;

import com.mycompany.sistemadeventas.modelo.Producto;
import java.util.ArrayList;

/**
 *
 * @author jival
 */
public interface ProductoDAO {
    String registrarProducto();
    ArrayList<Producto> obtenerProductos();
    Producto buscarProducto();
}
