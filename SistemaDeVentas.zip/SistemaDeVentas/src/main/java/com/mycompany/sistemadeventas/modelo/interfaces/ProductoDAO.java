package com.mycompany.sistemadeventas.modelo.interfaces;

import com.mycompany.sistemadeventas.modelo.Producto;
import java.util.ArrayList;
import java.util.HashMap;

public interface ProductoDAO {
    
    HashMap<String,Object> registrarProducto(Producto p);
    
    ArrayList<Producto> obtenerProductos();
    ArrayList<Producto> obtenerProductos(String modo);
    
    Producto buscarProducto(String id);
}
