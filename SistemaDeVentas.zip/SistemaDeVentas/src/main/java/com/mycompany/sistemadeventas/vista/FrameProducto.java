package com.mycompany.sistemadeventas.vista;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.AbstractTableModel;


public class FrameProducto extends javax.swing.JFrame {

    /**
     * Creates new form FrameProducto
     */
    public FrameProducto() {
        initComponents();
    }

    public JButton getBtnAgregarProducto() {
        return btnAgregarProducto;
    }

    public JLabel getLblInfoProductoReal() {
        return lblInfoProductoReal;
    }

    public void setLblInfoProductoReal(JLabel lblInfoProductoReal) {
        this.lblInfoProductoReal = lblInfoProductoReal;
    }
    
    
    
    public void setBtnAgregarProducto(JButton btnAgregarProducto) {
        this.btnAgregarProducto = btnAgregarProducto;
    }

    public JButton getBtnBuscarProducto() {
        return btnBuscarProducto;
    }

    public void setBtnBuscarProducto(JButton btnBuscarProducto) {
        this.btnBuscarProducto = btnBuscarProducto;
    }

    public ButtonGroup getButtonGroupSiNo() {
        return buttonGroupSiNo;
    }

    public void setButtonGroupSiNo(ButtonGroup buttonGroupSiNo) {
        this.buttonGroupSiNo = buttonGroupSiNo;
    }

    public ButtonGroup getButtonGroupTipoProducto() {
        return buttonGroupTipoProducto;
    }

    public void setButtonGroupTipoProducto(ButtonGroup buttonGroupTipoProducto) {
        this.buttonGroupTipoProducto = buttonGroupTipoProducto;
    }

    public JTextField getTxtId() {
        return txtId;
    }

    public void setTxtId(JTextField txtId) {
        this.txtId = txtId;
    }

    public JTextField getTxtMarca() {
        return txtMarca;
    }

    public void setTxtMarca(JTextField txtMarca) {
        this.txtMarca = txtMarca;
    }

    public JCheckBox getjCheckBoxMicroIncluido() {
        return jCheckBoxMicroIncluido;
    }

    public void setjCheckBoxMicroIncluido(JCheckBox jCheckBoxMicroIncluido) {
        this.jCheckBoxMicroIncluido = jCheckBoxMicroIncluido;
    }
    
    public JTextField getTxtNombre() {
        return txtNombre;
    }

    public void setTxtNombre(JTextField txtNombre) {
        this.txtNombre = txtNombre;
    }

    public JTextField getTxtPrecio() {
        return txtPrecio;
    }

    public void setTxtPrecio(JTextField txtPrecio) {
        this.txtPrecio = txtPrecio;
    }

    public JLabel getjLabel1() {
        return jLabel1;
    }

    public void setjLabel1(JLabel jLabel1) {
        this.jLabel1 = jLabel1;
    }

    public JLabel getjLabel3() {
        return jLabel3;
    }

    public void setjLabel3(JLabel jLabel3) {
        this.jLabel3 = jLabel3;
    }

    public JLabel getjLabel4() {
        return jLabel4;
    }

    public void setjLabel4(JLabel jLabel4) {
        this.jLabel4 = jLabel4;
    }

    public JLabel getjLabel7() {
        return jLabel7;
    }

    public void setjLabel7(JLabel jLabel7) {
        this.jLabel7 = jLabel7;
    }

    public JLabel getjLabel8() {
        return jLabel8;
    }

    public void setjLabel8(JLabel jLabel8) {
        this.jLabel8 = jLabel8;
    }

    public JPanel getjPanel1() {
        return jPanel1;
    }

    public void setjPanel1(JPanel jPanel1) {
        this.jPanel1 = jPanel1;
    }

    public JPanel getjPanel2() {
        return jPanel2;
    }

    public void setjPanel2(JPanel jPanel2) {
        this.jPanel2 = jPanel2;
    }

    public JRadioButton getjRbAudiofonos() {
        return jRbAudiofonos;
    }

    public void setjRbAudiofonos(JRadioButton jRbAudiofonos) {
        this.jRbAudiofonos = jRbAudiofonos;
    }

    public JRadioButton getjRbMouse() {
        return jRbMouse;
    }

    public void setjRbMouse(JRadioButton jRbMouse) {
        this.jRbMouse = jRbMouse;
    }

    public JRadioButton getjRbNo() {
        return jRbNo;
    }

    public void setjRbNo(JRadioButton jRbNo) {
        this.jRbNo = jRbNo;
    }

    public JRadioButton getjRbSi() {
        return jRbSi;
    }

    public void setjRbSi(JRadioButton jRbSi) {
        this.jRbSi = jRbSi;
    }

    public JScrollPane getjScrollPane1() {
        return jScrollPane1;
    }

    public void setjScrollPane1(JScrollPane jScrollPane1) {
        this.jScrollPane1 = jScrollPane1;
    }

    public JScrollPane getjScrollPane2() {
        return jScrollPane2;
    }

    public void setjScrollPane2(JScrollPane jScrollPane2) {
        this.jScrollPane2 = jScrollPane2;
    }

    public JLabel getLbCantidadBotones() {
        return lbCantidadBotones;
    }

    public void setLbCantidadBotones(JLabel lbCantidadBotones) {
        this.lbCantidadBotones = lbCantidadBotones;
    }

    public JLabel getLbMicrofono() {
        return lbMicrofono;
    }

    public void setLbMicrofono(JLabel lbMicrofono) {
        this.lbMicrofono = lbMicrofono;
    }

    

    public JTable getTbAudifonos() {
        return TbProductos;
    }

    public void setTbAudifonos(JTable tbAudifonos) {
        this.TbProductos = tbAudifonos;
    }

    public JTable getTbMouse() {
        return tbMouse;
    }

    public void setTbMouse(JTable tbMouse) {
        this.tbMouse = tbMouse;
    }

    public JPanel getPanelMicrofonoIncluido() {
        return PanelMicrofonoIncluido;
    }

    public void setPanelMicrofonoIncluido(JPanel PanelMicrofonoIncluido) {
        this.PanelMicrofonoIncluido = PanelMicrofonoIncluido;
    }

    public JPanel getPanelCantidadBotones() {
        return panelCantidadBotones;
    }

    public void setPanelCantidadBotones(JPanel panelCantidadBotones) {
        this.panelCantidadBotones = panelCantidadBotones;
    }

    public JSpinner getMedidorCantidadBotones() {
        return medidorCantidadBotones;
    }

    public JLabel getjLabel2() {
        return jLabel2;
    }

    public void setjLabel2(JLabel jLabel2) {
        this.jLabel2 = jLabel2;
    }

    public JPanel getjPanel3() {
        return jPanel3;
    }

    public void setjPanel3(JPanel jPanel3) {
        this.jPanel3 = jPanel3;
    }

    public JTable getTbProductos1() {
        return TbProductos1;
    }

    public void setTbProductos1(JTable TbProductos1) {
        this.TbProductos1 = TbProductos1;
    }

    public JPanel getjPanel4() {
        return pTbFiltrada;
    }

    public void setjPanel4(JPanel jPanel4) {
        this.pTbFiltrada = jPanel4;
    }

    
    public JScrollPane getjScrollPane3() {
        return jScrollPane3;
    }

    public void setjScrollPane3(JScrollPane jScrollPane3) {
        this.jScrollPane3 = jScrollPane3;
    }

  
 
    public ButtonGroup getModoVistaTablaProducto() {
        return modoVistaTablaProducto;
    }

    public void setModoVistaTablaProducto(ButtonGroup modoVistaTablaProducto) {
        this.modoVistaTablaProducto = modoVistaTablaProducto;
    }

    public JRadioButton getRbVistaTablaGeneral() {
        return rbVistaTablaGeneral;
    }

    public void setRbVistaTablaGeneral(JRadioButton rbVistaTablaGeneral) {
        this.rbVistaTablaGeneral = rbVistaTablaGeneral;
    }

    public JRadioButton getRbVistaTablasFiltradas() {
        return rbVistaTablasFiltradas;
    }

    public void setRbVistaTablasFiltradas(JRadioButton rbVistaTablasFiltradas) {
        this.rbVistaTablasFiltradas = rbVistaTablasFiltradas;
    }

    
    public void setMedidorCantidadBotones(JSpinner medidorCantidadBotones) {
        this.medidorCantidadBotones = medidorCantidadBotones;
    }
     public void actualizarInfoProducto(String mensaje){
        lblInfoProductoReal.setText(mensaje);
    }
    public void actualizarTablaMouse(AbstractTableModel absTableModel){
        tbMouse.setModel(absTableModel);
    }
    public void actualizarTablaAudifono(AbstractTableModel absTableModel){
        tbAudifonos1.setModel(absTableModel);
    }
    public void actualizarTablaProducto(AbstractTableModel absTableModel){
        TbProductos.setModel(absTableModel);
    }
    
    

    public JTable getTbProductos() {
        return TbProductos;
    }

    public void setTbProductos(JTable TbProductos) {
        this.TbProductos = TbProductos;
    }

    public JScrollPane getjScrollPane4() {
        return jScrollPane4;
    }

    public void setjScrollPane4(JScrollPane jScrollPane4) {
        this.jScrollPane4 = jScrollPane4;
    }

    public JTable getTbAudifonos1() {
        return tbAudifonos1;
    }

    public void setTbAudifonos1(JTable tbAudifonos1) {
        this.tbAudifonos1 = tbAudifonos1;
    }

    public JPanel getpTbFiltrada() {
        return pTbFiltrada;
    }

    public void setpTbFiltrada(JPanel pTbFiltrada) {
        this.pTbFiltrada = pTbFiltrada;
    }

    public JPanel getPanelTablaGeneral() {
        return panelTablaGeneral;
    }

    public void setPanelTablaGeneral(JPanel panelTablaGeneral) {
        this.panelTablaGeneral = panelTablaGeneral;
    }
    
    
//
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupTipoProducto = new javax.swing.ButtonGroup();
        buttonGroupSiNo = new javax.swing.ButtonGroup();
        modoVistaTablaProducto = new javax.swing.ButtonGroup();
        jScrollPane3 = new javax.swing.JScrollPane();
        TbProductos1 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        btnAgregarProducto = new javax.swing.JButton();
        btnBuscarProducto = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtMarca = new javax.swing.JTextField();
        jRbMouse = new javax.swing.JRadioButton();
        jRbAudiofonos = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jRbSi = new javax.swing.JRadioButton();
        jRbNo = new javax.swing.JRadioButton();
        panelCantidadBotones = new javax.swing.JPanel();
        lbCantidadBotones = new javax.swing.JLabel();
        medidorCantidadBotones = new javax.swing.JSpinner();
        PanelMicrofonoIncluido = new javax.swing.JPanel();
        lbMicrofono = new javax.swing.JLabel();
        jCheckBoxMicroIncluido = new javax.swing.JCheckBox();
        jPanel3 = new javax.swing.JPanel();
        rbVistaTablaGeneral = new javax.swing.JRadioButton();
        rbVistaTablasFiltradas = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        panelTablaGeneral = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TbProductos = new javax.swing.JTable();
        pTbFiltrada = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbMouse = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbAudifonos1 = new javax.swing.JTable();
        lblInfoProducto2 = new javax.swing.JLabel();
        lblInfoProductoReal = new javax.swing.JLabel();

        TbProductos1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Marca", "Precio", "Inalambrico", "Extra"
            }
        ));
        jScrollPane3.setViewportView(TbProductos1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setText("Precio");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 480, 43, 22));

        txtPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioActionPerformed(evt);
            }
        });
        getContentPane().add(txtPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 480, 171, -1));

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 16));

        btnAgregarProducto.setText("Agregar");
        jPanel2.add(btnAgregarProducto);

        btnBuscarProducto.setText("Buscar");
        jPanel2.add(btnBuscarProducto);

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 690, 220, -1));

        jPanel1.setLayout(new java.awt.GridLayout(1, 0));

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("ID:");
        jPanel8.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, 30, 30));

        txtId.setMinimumSize(new java.awt.Dimension(68, 16));
        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        jPanel8.add(txtId, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, 253, 30));

        jLabel3.setText("Nombre:");
        jPanel8.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, 30));
        jPanel8.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, 253, 30));

        jLabel4.setText("Marca:");
        jPanel8.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 40, 40));
        jPanel8.add(txtMarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 150, 253, 30));

        buttonGroupTipoProducto.add(jRbMouse);
        jRbMouse.setSelected(true);
        jRbMouse.setText("Mouse");
        jPanel8.add(jRbMouse, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 190, 80, 53));

        buttonGroupTipoProducto.add(jRbAudiofonos);
        jRbAudiofonos.setText("Audifonos");
        jRbAudiofonos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRbAudiofonosActionPerformed(evt);
            }
        });
        jPanel8.add(jRbAudiofonos, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 190, 90, 53));

        jLabel5.setText("TIpo:");
        jPanel8.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 30, 40));

        jPanel1.add(jPanel8);

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 450, 470, 260));

        jLabel8.setText("Inalambrico");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 520, 78, 22));

        buttonGroupSiNo.add(jRbSi);
        jRbSi.setSelected(true);
        jRbSi.setText("Si");
        jRbSi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRbSiActionPerformed(evt);
            }
        });
        getContentPane().add(jRbSi, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 520, -1, -1));

        buttonGroupSiNo.add(jRbNo);
        jRbNo.setText("No");
        jRbNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRbNoActionPerformed(evt);
            }
        });
        getContentPane().add(jRbNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 520, -1, -1));

        lbCantidadBotones.setText("Cantidad Botones");

        javax.swing.GroupLayout panelCantidadBotonesLayout = new javax.swing.GroupLayout(panelCantidadBotones);
        panelCantidadBotones.setLayout(panelCantidadBotonesLayout);
        panelCantidadBotonesLayout.setHorizontalGroup(
            panelCantidadBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCantidadBotonesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbCantidadBotones)
                .addGap(18, 18, 18)
                .addComponent(medidorCantidadBotones, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelCantidadBotonesLayout.setVerticalGroup(
            panelCantidadBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCantidadBotonesLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(panelCantidadBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbCantidadBotones, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(medidorCantidadBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        getContentPane().add(panelCantidadBotones, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 560, -1, 50));

        lbMicrofono.setText("Microfono");

        jCheckBoxMicroIncluido.setText("Incluido");
        jCheckBoxMicroIncluido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxMicroIncluidoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelMicrofonoIncluidoLayout = new javax.swing.GroupLayout(PanelMicrofonoIncluido);
        PanelMicrofonoIncluido.setLayout(PanelMicrofonoIncluidoLayout);
        PanelMicrofonoIncluidoLayout.setHorizontalGroup(
            PanelMicrofonoIncluidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMicrofonoIncluidoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbMicrofono, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBoxMicroIncluido)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelMicrofonoIncluidoLayout.setVerticalGroup(
            PanelMicrofonoIncluidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelMicrofonoIncluidoLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(PanelMicrofonoIncluidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbMicrofono, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBoxMicroIncluido))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        getContentPane().add(PanelMicrofonoIncluido, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 560, -1, 50));

        modoVistaTablaProducto.add(rbVistaTablaGeneral);
        rbVistaTablaGeneral.setSelected(true);
        rbVistaTablaGeneral.setText("Tabla General");
        rbVistaTablaGeneral.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbVistaTablaGeneralActionPerformed(evt);
            }
        });

        modoVistaTablaProducto.add(rbVistaTablasFiltradas);
        rbVistaTablasFiltradas.setText("Tablas Filtradas");

        jLabel2.setText("Modo de vista");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rbVistaTablasFiltradas, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbVistaTablaGeneral)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jLabel2)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbVistaTablaGeneral)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbVistaTablasFiltradas)
                .addGap(0, 19, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 650, -1, -1));

        TbProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tipo", "ID", "Nombre", "Marca", "Precio", "Inalambrico", "Extra"
            }
        ));
        jScrollPane1.setViewportView(TbProductos);

        javax.swing.GroupLayout panelTablaGeneralLayout = new javax.swing.GroupLayout(panelTablaGeneral);
        panelTablaGeneral.setLayout(panelTablaGeneralLayout);
        panelTablaGeneralLayout.setHorizontalGroup(
            panelTablaGeneralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTablaGeneralLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1043, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(87, Short.MAX_VALUE))
        );
        panelTablaGeneralLayout.setVerticalGroup(
            panelTablaGeneralLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTablaGeneralLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        pTbFiltrada.setPreferredSize(new java.awt.Dimension(1075, 385));

        tbMouse.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Marca", "Precio", "Inalabrico", "Cant. botones"
            }
        ));
        jScrollPane2.setViewportView(tbMouse);

        tbAudifonos1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Marca", "Precio", "Inalambrico", "Microfono"
            }
        ));
        jScrollPane4.setViewportView(tbAudifonos1);

        javax.swing.GroupLayout pTbFiltradaLayout = new javax.swing.GroupLayout(pTbFiltrada);
        pTbFiltrada.setLayout(pTbFiltradaLayout);
        pTbFiltradaLayout.setHorizontalGroup(
            pTbFiltradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pTbFiltradaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 525, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 514, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
        pTbFiltradaLayout.setVerticalGroup(
            pTbFiltradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pTbFiltradaLayout.createSequentialGroup()
                .addGap(0, 8, Short.MAX_VALUE)
                .addGroup(pTbFiltradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 373, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(9, 9, 9))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pTbFiltrada, javax.swing.GroupLayout.PREFERRED_SIZE, 1068, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelTablaGeneral, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(panelTablaGeneral, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pTbFiltrada, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 30, 1120, 410));
        getContentPane().add(lblInfoProducto2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));
        getContentPane().add(lblInfoProductoReal, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 620, 300, 44));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jRbSiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRbSiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRbSiActionPerformed

    private void jRbNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRbNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRbNoActionPerformed

    private void jCheckBoxMicroIncluidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxMicroIncluidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBoxMicroIncluidoActionPerformed

    private void rbVistaTablaGeneralActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbVistaTablaGeneralActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbVistaTablaGeneralActionPerformed

    private void txtPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecioActionPerformed

    private void jRbAudiofonosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRbAudiofonosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jRbAudiofonosActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PanelMicrofonoIncluido;
    private javax.swing.JTable TbProductos;
    private javax.swing.JTable TbProductos1;
    private javax.swing.JButton btnAgregarProducto;
    private javax.swing.JButton btnBuscarProducto;
    private javax.swing.ButtonGroup buttonGroupSiNo;
    private javax.swing.ButtonGroup buttonGroupTipoProducto;
    private javax.swing.JCheckBox jCheckBoxMicroIncluido;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JRadioButton jRbAudiofonos;
    private javax.swing.JRadioButton jRbMouse;
    private javax.swing.JRadioButton jRbNo;
    private javax.swing.JRadioButton jRbSi;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel lbCantidadBotones;
    private javax.swing.JLabel lbMicrofono;
    private javax.swing.JLabel lblInfoProducto2;
    private javax.swing.JLabel lblInfoProductoReal;
    private javax.swing.JSpinner medidorCantidadBotones;
    private javax.swing.ButtonGroup modoVistaTablaProducto;
    private javax.swing.JPanel pTbFiltrada;
    private javax.swing.JPanel panelCantidadBotones;
    private javax.swing.JPanel panelTablaGeneral;
    private javax.swing.JRadioButton rbVistaTablaGeneral;
    private javax.swing.JRadioButton rbVistaTablasFiltradas;
    private javax.swing.JTable tbAudifonos1;
    private javax.swing.JTable tbMouse;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPrecio;
    // End of variables declaration//GEN-END:variables
}
