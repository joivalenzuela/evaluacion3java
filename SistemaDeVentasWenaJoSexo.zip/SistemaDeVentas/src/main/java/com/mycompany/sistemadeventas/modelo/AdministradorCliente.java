package com.mycompany.sistemadeventas.modelo;

import java.util.ArrayList;
import com.mycompany.sistemadeventas.modelo.interfaces.ClienteDAO;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class AdministradorCliente implements ClienteDAO{

    ArrayList<Cliente> listaClientes;

    public AdministradorCliente() {
        listaClientes = new ArrayList<>();
    }
  
    
    
    @Override
     public HashMap<String,Object> agregarCliente(String run, String nombreCompleto, String correoElectronico, String telefono) {
        
        Pattern pattern = Pattern.compile("^[a-zA-ZÀ-ÿ\\u00f1\\u00d1]+(\\s*[a-zA-ZÀ-ÿ\\u00f1\\u00d1]*)*[a-zA-ZÀ-ÿ\\u00f1\\u00d1]+$");
        Matcher matcher = pattern.matcher(nombreCompleto);
        boolean matchFound = matcher.find();
         
        HashMap<String,Object> resuladoAgregar = new HashMap<>();
        
        for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
                setResult(resuladoAgregar, false, "El Cliente ingresado ya existe");
                return resuladoAgregar;
            }
        }
        if(!matchFound){
            setResult(resuladoAgregar, false, "El nombre ingresado no es valido");
        }else if(run.length()<9){
            setResult(resuladoAgregar, false, "El rut ingresado no es valido");
        }
        else if(!correoElectronico.contains("@")){
            setResult(resuladoAgregar, false, "El correo electronico ingresado no es valido");
        }
        else {
            setResult(resuladoAgregar, true, "Cliente agregado exitosamente");        
            Cliente nuevoCliente = new Cliente(run,nombreCompleto,correoElectronico);
            nuevoCliente.setTelefono(telefono);
            listaClientes.add(nuevoCliente);
        }
        return resuladoAgregar;
    }
     
     
     
    @Override
    public boolean eliminarCliente(String run) {
       for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
                listaClientes.remove(c);
                return true;
            }
        }
       return false;
    }

    
    
    @Override
    public HashMap<String,Object> editarCliente(String run, String nombreCompleto, String correoElectronico,  String telefono) {
        // exprecion regular para los nombres, sujeta a cambio.
        String regEx = "^[a-zA-ZÀ-ÿ\\u00f1\\u00d1]+(\\s*[a-zA-ZÀ-ÿ\\u00f1\\u00d1]*)*[a-zA-ZÀ-ÿ\\u00f1\\u00d1]+$";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(nombreCompleto);
        boolean matchFound = matcher.find();
        
        HashMap<String,Object> resuladoEditar = new HashMap<>();
        resuladoEditar.put("resultado", "nada");
     
        
        for(Cliente c : listaClientes){
            if(c.getRun().equalsIgnoreCase(run)){
                
                if(!matchFound && !nombreCompleto.isEmpty()){
                    setResult(resuladoEditar, false, "El nombre ingresado no es valido.");
                }else if(!correoElectronico.contains("@") && !correoElectronico.isEmpty()){
                    setResult(resuladoEditar, false, "El correo electronico ingresado no es valido.");
                }
                else{
                    //si los datos se dejan en blanco el metodo los ignora.
                    if(!nombreCompleto.isEmpty()){
                        c.setNombreCompleto(nombreCompleto);
                    }
                    if(!correoElectronico.isEmpty()){
                        c.setCorreoElectronico(correoElectronico);
                    }
                    // se deja el de telefono distinto para que se pueda elimina el dato de telefono ya que es opcional
                    c.setTelefono(telefono);
                    
                }
                setResult(resuladoEditar, true, "El correo electronico ingresado no es valido.");
                return resuladoEditar;
            }
        }
        setResult(resuladoEditar, false, "El correo electronico ingresado no es valido.");
        return resuladoEditar;
    }
    
   

    @Override
    public ArrayList<Cliente> obtenerClientes() {
        return listaClientes;
    }

    
    
    @Override
    public Cliente buscarCliente(String run) {
        for(Cliente c : listaClientes){
           if(c.getRun().equalsIgnoreCase(run)){
              return c;
           }
        }
        return null;
    }

    
    private void setResult(HashMap<String, Object> resultMap, boolean success, String message) {
        resultMap.put("resultado", success);
        resultMap.put("texto", message);
    }
}    

